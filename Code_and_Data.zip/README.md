# Reproducibility and submission files

The manuscript and supplement report 1,856 archived runs and 3,072 new resubmission runs. These are policy–scenario evaluations, not independent demand paths. All data are synthetic.

## Files

- manuscript/: clean manuscript, supplementary methods, editable LaTeX, tables, bibliography and vector figures.
- submission_documents/: point-by-point response, cover letter and author completion checklist.
- reproducibility/broad_study and focused_study: unchanged earlier simulator snapshots and result records.
- reproducibility/revision_study: frozen new design, executable experiments, tests, per-run trajectories and analyses.

## New experiments

Use Python with NumPy. ReportLab is additionally required to regenerate vector figures. See results/design.json for the exact tested versions and source hashes. Run from reproducibility/revision_study:

    python -m unittest test_simulator test_extensions test_revision
    python revision_experiment.py --stage parallel --workers 4
    python revision_experiment.py --stage cost
    python analyze_revision.py

The experiment runner checks the frozen source hashes and skips complete archived jobs. To reproduce all runs afresh, copy the folder and move its parallel.jsonl and cost.jsonl to a backup location within that copy before running. Do not use --freeze to overwrite the archived design. The cost stage should run alone, sequentially; concurrent experiments invalidate the intended timing conditions. Latency is platform-dependent and is not charged to simulated physical time.

The design was fixed locally before inspecting new results; it was not externally preregistered. The primary contrast is slowdown throughput with 128 fresh paired seeds. The four replication throughput contrasts additionally have Bonferroni-adjusted percentile bootstrap intervals. Other analyses are exploratory.

Build PDFs from manuscript/ with pdfLaTeX, BibTeX, then pdfLaTeX twice. The marked manuscript is a comparison against the originally supplied jimo source. The original sensitivity table is retained separately in the supplement. The current clean manuscript uses the expanded 32-seed sensitivity results.

No public repository DOI or editorial upload is claimed. Upload the reproducibility ZIP as supplementary material and check that the journal can access it. This local package does not perform submission.
