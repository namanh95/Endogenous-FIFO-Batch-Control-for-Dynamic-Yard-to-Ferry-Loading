"""Exact deterministic small-instance search and candidate-pruning audit."""
import csv
import json
from dataclasses import replace
from pathlib import Path
from simulator import *
from experiments import write_csv

def exact_value(s,end):
    memo={}; visited=0
    def key(st):
        return (round(st.t,10),tuple(tuple(v.id for v in q) for q in st.q),
                tuple(round(x,8) for x in st.lengths),tuple(round(x,8) for x in st.masses),
                tuple(st.slots),tuple(st.last_rank),round(st.payload,8),round(st.moment,8),st.last)
    def solve(st):
        nonlocal visited
        k=key(st)
        if k in memo: return memo[k]
        visited+=1
        base=objective(st,terminal=False)
        leaf=st.clone(); advance(leaf,end,[],0)
        if abs(end-st.cutoff)<EPS: close_cost(leaf)
        best=objective(leaf)-base  # no-arrival waiting until horizon
        for a in feasible(st,end):
            nxt=st.clone(); execute(nxt,a,[],0)
            delta=objective(nxt,terminal=False)-base
            best=min(best,delta+solve(nxt))
        memo[k]=best; return best
    value=solve(s)+objective(s,terminal=False)
    return value,visited

def policy_cost(s,policy,end,seed):
    st=s.clone(); d=0
    while st.t<end-EPS:
        acts=feasible(st,end)
        a=choose(st,policy,acts,0,seed+d)
        if a is None: idle(st,[],0,end)
        else: execute(st,a,[],0)
        d+=1
    close_cost(st)
    return objective(st)

def main():
    out=Path('small_audit'); out.mkdir(exist_ok=True)
    cfg=replace(Config(),yards=2,lanes=(Lane(length=14,transverse=-1),Lane(length=14,transverse=1)),
                initial=5,sailings=1,window=5,lookahead=5,eccentricity_limit=1,payload_limit=40)
    rows=[]; beams=[]
    for seed in range(5000,5024):
        s=State.empty(cfg); stream=arrivals(seed,0,cfg); advance(s,0,stream,0)
        optimum,visited=exact_value(s,5)
        for policy in POLICIES:
            cost=policy_cost(s,policy,5,seed)
            assert cost>=optimum-1e-7
            rows.append({'seed':seed,'policy':policy,'exact_cost':optimum,'policy_cost':cost,
                         'absolute_gap':cost-optimum,'relative_gap_pct':100*(cost/optimum-1) if optimum else 0,
                         'search_states':visited})
        for policy in ('deterministic_rollout','stochastic_rollout'):
            for beam in (1,5):
                _,full=rollout_values(s,feasible(s),policy,.48,seed,beam=0)
                _,pruned=rollout_values(s,feasible(s),policy,.48,seed,beam=beam)
                gap=min(pruned)-min(full)
                assert gap>=-1e-7
                beams.append({'seed':seed,'policy':policy,'beam':beam,'full_candidates':len(full),
                              'pruned_candidates':len(pruned),'rollout_score_gap':gap})
    write_csv(out/'exact_comparisons.csv',rows); write_csv(out/'pruning_comparisons.csv',beams)
    summary={p:{'mean_gap':float(np.mean([r['absolute_gap'] for r in rows if r['policy']==p])),
                'exact_matches':sum(abs(r['absolute_gap'])<1e-7 for r in rows if r['policy']==p),
                'cases':24} for p in POLICIES}
    summary['scope']='Exact no-arrival 5-minute subproblems only, not a stochastic global optimality claim.'
    (out/'summary.json').write_text(json.dumps(summary,indent=2)); print(json.dumps(summary,indent=2))

if __name__=='__main__': main()
