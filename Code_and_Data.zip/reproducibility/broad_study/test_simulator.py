import json
import unittest
from dataclasses import replace
from pathlib import Path
import numpy as np
from simulator import *

def v(i=0,t=0,y=0,rank=1,width=1.8,mass=1.5):
    return Vehicle(i,t,y,0,4.2,width,1.6,mass,.5,1.0,rank,0)

def state_with(cfg,vehicles):
    s=State.empty(cfg,record=True)
    advance(s,0,vehicles,0)
    return s

class SimulatorTests(unittest.TestCase):
    def test_gated_fifo_with_midbatch_arrival(self):
        cfg=Config(initial=0); stream=[v(0),v(1),v(2,t=.6)]
        s=state_with(cfg,stream); a=next(a for a in feasible(s) if a.size==2 and a.lane==0)
        idx=execute(s,a,stream,2,validate=True)
        self.assertEqual(idx,3); self.assertEqual([x.id for x in s.q[0]],[2])
        self.assertEqual([x[0] for x in s.completed],[0,1])

    def test_exact_cutoff_and_overrun(self):
        cfg=replace(Config(),window=1.0,initial=0)
        s=state_with(cfg,[v()]); self.assertTrue(feasible(s))
        s.cutoff=.999; self.assertFalse(feasible(s))

    def test_incompatible_head_cannot_be_skipped(self):
        cfg=replace(Config(),lanes=(Lane(width=2.0),),initial=0)
        s=state_with(cfg,[v(width=2.5),v(1)])
        self.assertFalse(feasible(s))

    def test_length_mass_slots_and_payload(self):
        for lane,plim in [(Lane(length=4.4),65),(Lane(mass=1.4),65),
                          (Lane(slots=0),65),(Lane(),1.4)]:
            cfg=replace(Config(),lanes=(lane,),payload_limit=plim,initial=0)
            self.assertFalse(feasible(state_with(cfg,[v()])))

    def test_discharge_order(self):
        s=state_with(Config(initial=0),[v(rank=1),v(1,rank=2)])
        self.assertTrue(all(a.size==1 for a in feasible(s)))

    def test_balance_and_lane_closure(self):
        cfg=replace(Config(),lanes=(Lane(transverse=3),),eccentricity_limit=.01,initial=0)
        self.assertFalse(feasible(state_with(cfg,[v()])))
        s=state_with(Config(initial=0),[v()]); s.mode=Mode(blocked=(0,1,2,3))
        self.assertFalse(feasible(s))

    def test_cancelled_sailing_carryover_and_reset(self):
        cfg=replace(Config(),sailings=2,shock_sailing=0,initial=0)
        stream=[v(0),v(1)]
        r=simulate(cfg,stream,0,'myopic','cancelled',7,True)
        self.assertEqual(r['per_sailing'][0]['boarded'],0)
        self.assertEqual(r['per_sailing'][0]['backlog'],2)
        self.assertEqual(r['per_sailing'][1]['boarded'],2)
        self.assertEqual(r['deferrals'],2)

    def test_sampled_recovery_span_and_censoring(self):
        grid=np.arange(15.)
        values=np.ones(15)*20; values[:10]=0
        self.assertIsNone(sustained_confirmation(grid,values,0,10,10))
        values[10]=0
        self.assertEqual(sustained_confirmation(grid,values,0,10,10),10)
        self.assertIsNone(sustained_confirmation(grid,values,6,10,10))

    def test_forecasts_do_not_mutate_observed_state(self):
        cfg=replace(Config(),initial=5,sailings=2)
        stream=arrivals(12,.2,cfg)
        s=State.empty(cfg); advance(s,0,stream,0)
        before=repr(s)
        a1=choose(s,'stochastic_rollout',feasible(s),.2,91)
        a2=choose(s,'stochastic_rollout',feasible(s),.2,91)
        self.assertEqual(a1,a2); self.assertEqual(before,repr(s))
        # choose has no real-stream parameter: swapping unseen real arrivals cannot affect it.

    def test_zero_disruption_contrast(self):
        cfg=replace(Config(),sailings=5,initial=3)
        r=simulate(cfg,arrivals(18,.1,cfg),.1,'myopic','nominal',18)
        other=dict(r,scenario='cancelled')
        metrics=paired_disruption_metrics(other,r,cfg)
        self.assertAlmostEqual(metrics['positive_service_lag_area'],0)
        self.assertAlmostEqual(metrics['excess_backlog_area'],0)

    def test_small_paired_paths_all_policies(self):
        for seed in range(3):
            cfg=replace(Config(),sailings=2,window=8,initial=4,shock_sailing=0,
                        lookahead=5,beam=3,scenarios=2,mixed_discharge=True)
            stream=arrivals(seed,.2,cfg)
            for policy in POLICIES:
                r=simulate(cfg,stream,.2,policy,'slow_handling',seed)
                self.assertEqual(r['arrived'],r['boarded']+r['end_backlog'])
                self.assertLess(r['accounting_error'],1e-6)
                self.assertEqual(r['violations'],0)

if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(SimulatorTests)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    Path('test_results.json').write_text(json.dumps({
        'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
        'successful':result.wasSuccessful()},indent=2))
    raise SystemExit(not result.wasSuccessful())
