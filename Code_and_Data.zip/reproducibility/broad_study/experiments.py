"""Predeclared paired synthetic experiment and bootstrap summaries."""
import argparse
import csv
import hashlib
import json
import platform
import time
from dataclasses import asdict, replace
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import numpy as np
from simulator import *

RATES=(.32,.48,.65)
SCENARIOS=('nominal','cancelled','lane_closure','slow_handling')

def write_csv(path,rows):
    if not rows: return
    keys=list(dict.fromkeys(k for row in rows for k in row))
    with Path(path).open('w',newline='',encoding='utf-8') as f:
        wr=csv.DictWriter(f,fieldnames=keys); wr.writeheader(); wr.writerows(rows)

def task(args):
    seed,rate,scenarios,policies,cfg=args
    stream=arrivals(seed,rate,cfg)
    digest=hashlib.sha256(json.dumps([asdict(v) for v in stream],sort_keys=True).encode()).hexdigest()
    results=[]; details={}
    for policy in policies:
        nominal=None
        for scenario in scenarios:
            r=simulate(cfg,stream,rate,policy,scenario,seed,keep_trace=(seed==1000 and rate==.48))
            if scenario=='nominal': nominal=r
            if scenario!='nominal': r.update(paired_disruption_metrics(r,nominal,cfg))
            r['arrival_sha256']=digest
            key=f'{seed}_{rate}_{policy}_{scenario}'
            details[key]=r
            results.append({k:v for k,v in r.items() if not isinstance(v,(list,dict))})
    return results,details

def summarize(rows,out):
    groups={}
    for r in rows: groups.setdefault((r['rate'],r['scenario'],r['policy']),[]).append(r)
    metrics=['boarded','end_backlog','weighted_residence','deferrals','objective',
             'setup_minutes','loaded_lane_metres','latency_mean_ms','latency_p99_ms',
             'positive_service_lag_area','excess_backlog_area','end_service_gap',
             'restricted_confirmation_minutes','relative_restricted_minutes']
    summaries=[]
    for key,g in sorted(groups.items()):
        row=dict(zip(['rate','scenario','policy'],key)); row['n']=len(g)
        for m in metrics:
            values=[x[m] for x in g if x.get(m) is not None]
            if values: row[m+'_mean']=float(np.mean(values))
        if key[1]!='nominal':
            row['nonrecovery_fraction']=1-float(np.mean([x['recovered'] for x in g]))
            row['relative_nonrecovery_fraction']=1-float(np.mean([x['relative_recovered'] for x in g]))
            row['nominal_threshold_reach_fraction']=float(np.mean([x['nominal_reaches_threshold'] for x in g]))
        summaries.append(row)
    write_csv(out/'summary.csv',summaries)
    # Pointwise percentile bootstrap across paired seeds; do not resample policies independently.
    paired=[]; rng=np.random.default_rng(20261022)
    index={(r['rate'],r['scenario'],r['policy'],r['seed']):r for r in rows}
    for (rate,scenario,policy),g in sorted(groups.items()):
        if policy=='myopic': continue
        seeds=[x['seed'] for x in g]
        for metric in ['boarded','weighted_residence','deferrals','objective',
                       'positive_service_lag_area','restricted_confirmation_minutes']:
            diffs=[]; baselines=[]
            for seed in seeds:
                ref=index.get((rate,scenario,'myopic',seed)); val=index[(rate,scenario,policy,seed)]
                if ref and ref.get(metric) is not None and val.get(metric) is not None:
                    diffs.append(val[metric]-ref[metric]); baselines.append(ref[metric])
            if not diffs: continue
            d=np.array(diffs); n=len(d)
            boots=np.mean(d[rng.integers(n,size=(3000,n))],axis=1)
            paired.append({'rate':rate,'scenario':scenario,'policy':policy,'reference':'myopic',
                           'metric':metric,'n':n,'mean_difference':float(d.mean()),
                           'ci_low':float(np.quantile(boots,.025)),'ci_high':float(np.quantile(boots,.975)),
                           'mean_reference':float(np.mean(baselines))})
    write_csv(out/'paired_comparisons.csv',paired)
    return summaries,paired

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--seeds',type=int,default=30)
    ap.add_argument('--rates',type=float,nargs='+',default=RATES)
    ap.add_argument('--scenarios',nargs='+',default=SCENARIOS)
    ap.add_argument('--policies',nargs='+',default=POLICIES)
    ap.add_argument('--workers',type=int,default=1)
    ap.add_argument('--out',default='results')
    ap.add_argument('--stress',action='store_true')
    args=ap.parse_args(); out=Path(args.out); out.mkdir(exist_ok=True,parents=True)
    assert args.scenarios[0]=='nominal', 'matched nominal run must precede disruptions'
    cfg=Config(mixed_discharge=args.stress)
    manifest={'config':asdict(cfg),'rates':args.rates,'scenarios':args.scenarios,'policies':args.policies,
              'seeds':list(range(1000,1000+args.seeds)),'workers':args.workers,
              'python':platform.python_version(),'numpy':np.__version__,
              'platform':platform.platform(),'processor':platform.processor(),
              'timing_assumption':'CPU latency measured but consumes zero simulated physical time',
              'status':'synthetic prototype; no field calibration or stability guarantee',
              'analysis':'3000 paired-seed percentile bootstrap replicates; pointwise 95% intervals',
              'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()
                               for p in [Path('simulator.py'),Path('experiments.py')]}}
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2))
    jobs=[(seed,rate,args.scenarios,args.policies,cfg) for rate in args.rates for seed in manifest['seeds']]
    rows=[]; tic=time.perf_counter()
    executor=ProcessPoolExecutor(args.workers) if args.workers>1 else None
    iterator=executor.map(task,jobs) if executor else map(task,jobs)
    with (out/'details.jsonl').open('w',encoding='utf-8') as f:
        for j,(result,details) in enumerate(iterator,1):
            rows.extend(result)
            for key,value in details.items(): f.write(json.dumps({'key':key,**value})+'\n')
            f.flush()
            write_csv(out/'runs.csv',rows)
            print(f'{j}/{len(jobs)} paired demand paths; {len(rows)} runs; elapsed {time.perf_counter()-tic:.1f}s',flush=True)
    if executor: executor.shutdown()
    summarize(rows,out)
    (out/'run_totals.json').write_text(json.dumps({'runs':len(rows),'paired_demand_paths':len(jobs),
         'elapsed_s':time.perf_counter()-tic,'audit_boardings':sum(r['audit_boardings'] for r in rows),
         'violations':sum(r['violations'] for r in rows),'maximum_accounting_error':max(r['accounting_error'] for r in rows)},indent=2))
    print('Completed; raw data and paired summaries saved.',flush=True)

if __name__=='__main__': main()
