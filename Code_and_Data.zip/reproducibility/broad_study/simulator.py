"""Auditable synthetic FIFO ferry simulator. Physical units: minutes, metres, tonnes.

Only observed state enters policies. Real future arrivals are owned by the engine.
Scenario rollouts use independently generated forecasts, common across candidates.
"""
from dataclasses import dataclass, field, asdict
from collections import Counter
import math
import time
import numpy as np

EPS = 1e-9
POLICIES = ('fixed2', 'myopic', 'deterministic_rollout', 'stochastic_rollout')

@dataclass(frozen=True)
class Vehicle:
    id: int
    arrival: float
    yard: int
    cls: int
    length: float
    width: float
    height: float
    mass: float
    handling: float
    weight: float
    rank: int
    preferred: int

@dataclass(frozen=True)
class Lane:
    length: float = 28.0
    width: float = 2.7
    height: float = 4.5
    mass: float = 30.0
    slots: int = 6
    transverse: float = 0.0

@dataclass(frozen=True)
class Config:
    yards: int = 4
    lanes: tuple = (Lane(width=2.25,height=2.6,mass=10,transverse=-3),
                    Lane(width=2.25,height=2.6,mass=10,transverse=3),
                    Lane(transverse=-1), Lane(transverse=1))
    sailings: int = 12
    cycle: float = 40.0
    window: float = 24.0
    initial: int = 12
    clearance: float = .25
    reference_mass: float = 60.0
    payload_limit: float = 65.0
    eccentricity_limit: float = .6
    review: float = 2.0
    lookahead: float = 12.0
    beam: int = 5
    scenarios: int = 3
    gamma: float = 2.0
    deferral_cost: float = 20.0
    setup_cost: float = 2.0
    shock_sailing: int = 3
    recovery_threshold: int = 10
    recovery_hold: int = 10
    grid_step: float = 1.0
    mixed_discharge: bool = False

    @property
    def horizon(self):
        return (self.sailings - 1)*self.cycle+self.window

@dataclass(frozen=True)
class Mode:
    blocked: tuple = ()
    multiplier: float = 1.0
    cancelled: bool = False

@dataclass(frozen=True)
class Action:
    yard: int
    size: int
    lane: int
    setup: float
    duration: float

@dataclass
class State:
    cfg: Config
    t: float = 0.0
    k: int = 0
    cutoff: float = 24.0
    q: list = field(default_factory=list)
    lengths: list = field(default_factory=list)
    masses: list = field(default_factory=list)
    slots: list = field(default_factory=list)
    last_rank: list = field(default_factory=list)
    payload: float = 0.0
    moment: float = 0.0
    last: tuple | None = None
    mode: Mode = Mode()
    area: float = 0.0
    wait_weight: float = 0.0
    setup_minutes: float = 0.0
    missed: int = 0
    missed_weight: float = 0.0
    completed: list | None = None
    trace: list | None = None

    @classmethod
    def empty(cls, cfg, record=False):
        n=len(cfg.lanes)
        return cls(cfg=cfg, cutoff=cfg.window, q=[[] for _ in range(cfg.yards)],
                   lengths=[0.0]*n,masses=[0.0]*n,slots=[0]*n,last_rank=[math.inf]*n,
                   completed=[] if record else None, trace=[] if record else None)

    def clone(self):
        # Immutable vehicle records are shared; mutable lists are isolated.
        return State(self.cfg,self.t,self.k,self.cutoff,[x.copy() for x in self.q],
                     self.lengths.copy(),self.masses.copy(),self.slots.copy(),
                     self.last_rank.copy(),self.payload,self.moment,self.last,self.mode,
                     self.area,self.wait_weight,self.setup_minutes,self.missed,
                     self.missed_weight,None,None)

    def open_window(self,k,mode):
        self.k=k; self.cutoff=k*self.cfg.cycle+self.cfg.window; self.mode=mode
        n=len(self.cfg.lanes)
        self.lengths=[0.0]*n; self.masses=[0.0]*n; self.slots=[0]*n
        self.last_rank=[math.inf]*n; self.payload=0.0; self.moment=0.0; self.last=None

    def counts(self):
        return [sum(v.cls==c for lane in self.q for v in lane) for c in range(3)]

def preferred_sailing(arrival,cfg):
    return max(0,math.ceil((arrival-cfg.window)/cfg.cycle-EPS))

def vehicle(rng,idx,t,cfg):
    c=int(rng.choice(3,p=[.65,.20,.15]))
    dims=((4.2,1.8,1.6,1.5,.55),(5.5,2.1,2.4,3.2,.70),(8.0,2.55,3.8,12.0,1.0))[c]
    return Vehicle(idx,float(t),int(rng.integers(cfg.yards)),c,*dims,
                   3.0 if rng.random()<.15 else 1.0,
                   2 if cfg.mixed_discharge and rng.random()<.25 else 1,
                   preferred_sailing(t,cfg))

def arrivals(seed,rate,cfg,start=0.0,end=None,initial=True,id_offset=0):
    rng=np.random.default_rng(seed)
    end=cfg.horizon if end is None else end
    out=[]
    if initial:
        for _ in range(cfg.initial): out.append(vehicle(rng,id_offset+len(out),start,cfg))
    t=start
    if rate>0:
        while True:
            t+=float(rng.exponential(1/rate))
            if t>=end-EPS: break
            out.append(vehicle(rng,id_offset+len(out),t,cfg))
    return out

def setup_time(s,y,p):
    raw=.5 if s.last is None else .15+.30*(s.last[0]!=y)+.25*(s.last[1]!=p)
    return raw*s.mode.multiplier

def feasible(s,end=None,rejections=None):
    cfg=s.cfg; end=s.cutoff if end is None else min(end,s.cutoff)
    if s.mode.cancelled: return []
    out=[]
    for y,queue in enumerate(s.q):
        if not queue: continue
        for p,lane in enumerate(cfg.lanes):
            if p in s.mode.blocked: continue
            length=s.lengths[p]; mass=s.masses[p]; slots=s.slots[p]
            payload=s.payload; moment=s.moment; rank=s.last_rank[p]
            setup=setup_time(s,y,p); dur=setup
            for b,v in enumerate(queue,1):
                length+=v.length+cfg.clearance; mass+=v.mass; slots+=1
                payload+=v.mass; moment+=v.mass*lane.transverse
                dur+=v.handling*s.mode.multiplier
                reason=None
                if v.width>lane.width+EPS or v.height>lane.height+EPS: reason='compatibility'
                elif length>lane.length+EPS: reason='length'
                elif mass>lane.mass+EPS or payload>cfg.payload_limit+EPS: reason='mass'
                elif slots>lane.slots: reason='slots'
                elif rank<v.rank: reason='discharge'
                elif abs(moment)>cfg.eccentricity_limit*(cfg.reference_mass+payload)+EPS: reason='balance'
                elif s.t+dur>end+EPS: reason='cutoff'
                if reason:
                    if rejections is not None: rejections[reason]+=1
                    break  # every executed prefix must pass
                rank=v.rank
                out.append(Action(y,b,p,setup,dur))
    return out

def advance(s,end,stream,idx):
    assert end>=s.t-EPS
    while idx<len(stream) and stream[idx].arrival<=end+EPS:
        v=stream[idx]
        assert v.arrival>=s.t-EPS
        s.area+=s.wait_weight*max(0,v.arrival-s.t); s.t=v.arrival
        s.q[v.yard].append(v); s.wait_weight+=v.weight; idx+=1
    s.area+=s.wait_weight*max(0,end-s.t); s.t=end
    return idx

def execute(s,a,stream,idx,validate=False):
    if validate: assert a in feasible(s), ('invalid launch',s.t,a)
    batch=s.q[a.yard][:a.size]
    start=s.t
    if s.trace is not None:
        s.trace.append({'k':s.k,'start':start,'end':start+a.duration,
                        'yard':a.yard,'lane':a.lane,'ids':[v.id for v in batch],
                        'setup':a.setup,'multiplier':s.mode.multiplier,
                        'blocked':list(s.mode.blocked)})
    completion=start+a.setup
    for v in batch:
        completion+=v.handling*s.mode.multiplier
        idx=advance(s,completion,stream,idx)
        assert s.q[a.yard][0].id==v.id, 'FIFO corruption'
        s.q[a.yard].pop(0); s.wait_weight-=v.weight
        p=a.lane
        s.lengths[p]+=v.length+s.cfg.clearance; s.masses[p]+=v.mass
        s.slots[p]+=1; s.last_rank[p]=v.rank
        s.payload+=v.mass; s.moment+=v.mass*s.cfg.lanes[p].transverse
        if s.completed is not None: s.completed.append((v.id,completion,p,s.k))
    s.setup_minutes+=a.setup; s.last=(a.yard,a.lane)
    assert abs(s.t-(start+a.duration))<1e-7
    return idx

def close_cost(s):
    due=[v for lane in s.q for v in lane if v.preferred<=s.k]
    s.missed+=len(due); s.missed_weight+=sum(v.weight for v in due)

def objective(s,terminal=True):
    val=s.area+s.cfg.deferral_cost*s.missed_weight+s.cfg.setup_cost*s.setup_minutes
    return val+(s.cfg.gamma*sum(n*n for n in s.counts()) if terminal else 0)

def myopic_key(s,a):
    batch=s.q[a.yard][:a.size]
    benefit=sum(v.weight*(1+.04*(s.t-v.arrival)+2*(v.preferred<=s.k)) for v in batch)
    residual=s.cfg.lanes[a.lane].length-s.lengths[a.lane]-sum(v.length+s.cfg.clearance for v in batch)
    return (benefit/a.duration,a.size,-residual,-a.yard,-a.lane)

def myopic(s,acts):
    return max(acts,key=lambda a:myopic_key(s,a)) if acts else None

def fixed2(s,acts):
    acts=[a for a in acts if a.size<=2]
    if not acts: return None
    def key(a):
        rem=s.cfg.lanes[a.lane].length-s.lengths[a.lane]-sum(v.length+s.cfg.clearance for v in s.q[a.yard][:a.size])
        return (s.q[a.yard][0].arrival,-a.size,rem,a.yard,a.lane)
    return min(acts,key=key)

def idle(s,stream,idx,end):
    nxt=min(end,s.t+s.cfg.review)
    if idx<len(stream): nxt=min(nxt,stream[idx].arrival)
    assert nxt>s.t+EPS, ('zero-time idle',s.t,nxt)
    return advance(s,nxt,stream,idx)

def continuation_cost(state,first,forecast,end):
    s=state.clone(); idx=0
    if first is None: idx=idle(s,forecast,idx,end)
    else: idx=execute(s,first,forecast,idx)
    while s.t<end-EPS:
        acts=feasible(s,end)
        a=myopic(s,acts)
        if a is None: idx=idle(s,forecast,idx,end)
        else: idx=execute(s,a,forecast,idx)
    if abs(end-s.cutoff)<EPS: close_cost(s)
    return objective(s)

def rollout_values(s,acts,policy,rate,seed,beam=None):
    end=min(s.cutoff,s.t+s.cfg.lookahead)
    # Batches fit the calendar horizon, avoiding partially executed terminal states.
    eligible=[a for a in acts if s.t+a.duration<=end+EPS]
    if not eligible: return [],[]
    ranked=sorted(eligible,key=lambda a:myopic_key(s,a),reverse=True)
    cap=s.cfg.beam if beam is None else beam
    candidates=ranked if cap==0 else ranked[:cap]
    candidates=candidates+[None]
    scenarios=[[]] if policy=='deterministic_rollout' else [
        arrivals(2000000000+seed+7919*j,rate,s.cfg,start=s.t,end=end,initial=False,id_offset=1000000+j*10000)
        for j in range(s.cfg.scenarios)]
    values=[sum(continuation_cost(s,a,f,end) for f in scenarios)/len(scenarios) for a in candidates]
    return candidates,values

def choose(s,policy,acts,rate,seed):
    if not acts: return None
    if policy=='fixed2': return fixed2(s,acts)
    if policy=='myopic': return myopic(s,acts)
    cand,values=rollout_values(s,acts,policy,rate,seed)
    return cand[min(range(len(cand)),key=lambda j:values[j])] if cand else myopic(s,acts)

def mode_for(scenario,k,cfg):
    hit=cfg.shock_sailing
    if scenario=='cancelled' and k==hit: return Mode(cancelled=True)
    if scenario=='lane_closure' and k in (hit,hit+1): return Mode(blocked=(2,))
    if scenario=='slow_handling' and k in (hit,hit+1): return Mode(multiplier=1.8)
    return Mode()

def restoration_time(scenario,cfg):
    return (cfg.shock_sailing+(1 if scenario=='cancelled' else 2))*cfg.cycle

def independent_audit(cfg,stream,trace,completed,finalq):
    """Replay actions using full records, independently of feasible() decisions."""
    byid={v.id:v for v in stream}; queues=[[] for _ in range(cfg.yards)]
    ptr=0; served=set(); last_k=-1; prev_end=0.0; checks=0
    bycompletion={x[0]:x for x in completed}
    for batch in trace:
        start=batch['start']; k=batch['k']; y=batch['yard']; p=batch['lane']; ids=batch['ids']
        assert start>=prev_end-EPS and start>=k*cfg.cycle-EPS
        assert batch['end']<=k*cfg.cycle+cfg.window+EPS
        while ptr<len(stream) and stream[ptr].arrival<=start+EPS:
            v=stream[ptr]; queues[v.yard].append(v.id); ptr+=1
        assert queues[y][:len(ids)]==ids, 'independent FIFO audit'
        del queues[y][:len(ids)]
        if k!=last_k:
            onboard=[[] for _ in cfg.lanes]; last_config=None; last_k=k
        raw=.5 if last_config is None else .15+.30*(last_config[0]!=y)+.25*(last_config[1]!=p)
        expected_setup=raw*batch['multiplier']
        assert abs(batch['setup']-expected_setup)<1e-8
        finish=start+expected_setup
        for vid in ids:
            assert vid not in served and p not in batch['blocked']
            v=byid[vid]; lane=cfg.lanes[p]
            assert v.arrival<=start+EPS
            assert v.width<=lane.width+EPS and v.height<=lane.height+EPS
            if onboard[p]: assert onboard[p][-1].rank>=v.rank
            onboard[p].append(v)
            assert len(onboard[p])<=lane.slots
            assert sum(w.length+cfg.clearance for w in onboard[p])<=lane.length+EPS
            assert sum(w.mass for w in onboard[p])<=lane.mass+EPS
            payload=sum(w.mass for group in onboard for w in group)
            moment=sum(w.mass*cfg.lanes[j].transverse for j,group in enumerate(onboard) for w in group)
            assert payload<=cfg.payload_limit+EPS
            assert abs(moment)<=cfg.eccentricity_limit*(cfg.reference_mass+payload)+EPS
            finish+=v.handling*batch['multiplier']
            assert abs(bycompletion[vid][1]-finish)<1e-7
            served.add(vid); checks+=1
        assert abs(finish-batch['end'])<1e-7
        prev_end=finish; last_config=(y,p)
    remaining={v.id for lane in finalq for v in lane}
    assert served.isdisjoint(remaining) and served|remaining==set(byid)
    return checks

def simulate(cfg,stream,rate,policy,scenario,seed,keep_trace=False):
    started=time.perf_counter(); s=State.empty(cfg,record=True); idx=0
    latencies=[]; rejects=Counter(); decision=0; per_sailing=[]
    for k in range(cfg.sailings):
        idx=advance(s,k*cfg.cycle,stream,idx)
        s.open_window(k,mode_for(scenario,k,cfg)); before=len(s.completed)
        if s.mode.cancelled:
            idx=advance(s,s.cutoff,stream,idx)
        else:
            while s.t<s.cutoff-EPS:
                tic=time.perf_counter()
                acts=feasible(s,rejections=rejects)
                a=choose(s,policy,acts,rate,seed+1000003*decision+17*k)
                latencies.append(time.perf_counter()-tic); decision+=1
                if a is None: idx=idle(s,stream,idx,s.cutoff)
                else: idx=execute(s,a,stream,idx,validate=True)
        close_cost(s)
        per_sailing.append({'k':k,'boarded':len(s.completed)-before,'backlog':sum(map(len,s.q))})
    assert idx==len(stream)
    completion={i:t for i,t,p,k in s.completed}
    direct=sum(v.weight*(completion.get(v.id,cfg.horizon)-v.arrival) for v in stream)
    error=abs(direct-s.area)
    assert error<1e-6, ('residence identity',error)
    checks=independent_audit(cfg,stream,s.trace,s.completed,s.q)
    grid=np.arange(0,cfg.horizon+cfg.grid_step/2,cfg.grid_step)
    at=np.array([v.arrival for v in stream]); ct=np.sort([x[1] for x in s.completed])
    ac=np.searchsorted(at,grid,side='right'); dc=np.searchsorted(ct,grid,side='right')
    q=ac-dc
    result={'policy':policy,'scenario':scenario,'rate':rate,'seed':seed,
            'arrived':len(stream),'boarded':len(s.completed),'end_backlog':sum(map(len,s.q)),
            'weighted_residence':s.area,'deferrals':s.missed,'weighted_deferrals':s.missed_weight,
            'setup_minutes':s.setup_minutes,'objective':objective(s),
            'loaded_lane_metres':sum(v.length+cfg.clearance for v in stream if v.id in completion),
            'audit_boardings':checks,'violations':0,'accounting_error':error,
            'decisions':decision,'runtime_s':time.perf_counter()-started,
            'latency_mean_ms':1000*float(np.mean(latencies)) if latencies else 0,
            'latency_p99_ms':1000*float(np.quantile(latencies,.99)) if latencies else 0,
            'latency_max_ms':1000*max(latencies,default=0),
            'rejections':dict(rejects),'per_sailing':per_sailing,
            'boarded_by_class':[sum(v.cls==c and v.id in completion for v in stream) for c in range(3)],
            'completions':s.completed,'grid':grid.tolist(),'queue':q.tolist(),'service':dc.tolist()}
    if keep_trace: result['trace']=s.trace
    return result

def sustained_confirmation(grid,values,start,threshold,hold):
    step=grid[1]-grid[0]; m=int(round(hold/step))
    eligible=np.asarray(grid)>=start-EPS
    ids=np.flatnonzero(eligible)
    if not len(ids): return None
    first=ids[0]
    good=np.asarray(values)<=threshold
    for j in range(first,len(grid)-m):
        if np.all(good[j:j+m+1]): return float(grid[j+m]-start)
    return None

def paired_disruption_metrics(result,nominal,cfg):
    if result['scenario']=='nominal': return {}
    shock=cfg.shock_sailing*cfg.cycle; restore=restoration_time(result['scenario'],cfg)
    # Exact integration of completed-count differences over merged event times.
    events={shock,cfg.horizon}
    events.update(t for _,t,_,_ in result['completions'] if t>=shock)
    events.update(t for _,t,_,_ in nominal['completions'] if t>=shock)
    grid=sorted(events)
    actual=np.sort([t for _,t,_,_ in result['completions']])
    baseline=np.sort([t for _,t,_,_ in nominal['completions']])
    signed=positive=0.0
    for a,b in zip(grid,grid[1:]):
        gap=int(np.searchsorted(baseline,a+EPS,side='right')-np.searchsorted(actual,a+EPS,side='right'))
        signed+=gap*(b-a); positive+=max(0,gap)*(b-a)
    rg=np.array(result['grid']); rq=np.array(result['queue']); nq=np.array(nominal['queue'])
    absolute=sustained_confirmation(rg,rq,restore,cfg.recovery_threshold,cfg.recovery_hold)
    reference=sustained_confirmation(rg,nq,restore,cfg.recovery_threshold,cfg.recovery_hold)
    relative=sustained_confirmation(rg,rq-nq,restore,2,cfg.recovery_hold)
    horizon=cfg.horizon-restore
    return {'excess_backlog_area':signed,'positive_service_lag_area':positive,
            'end_service_gap':max(0,nominal['boarded']-result['boarded']),
            'recovered':absolute is not None,'confirmation_minutes':absolute,
            'restricted_confirmation_minutes':horizon if absolute is None else absolute,
            'nominal_reaches_threshold':reference is not None,
            'relative_recovered':relative is not None,
            'relative_confirmation_minutes':relative,
            'relative_restricted_minutes':horizon if relative is None else relative,
            'recovery_followup_minutes':horizon}

