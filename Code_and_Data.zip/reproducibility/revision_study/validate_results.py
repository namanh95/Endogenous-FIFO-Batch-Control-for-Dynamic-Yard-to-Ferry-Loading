"""Validate the distributed evidence against the frozen experimental design."""
import json,hashlib,csv
from pathlib import Path
from collections import Counter,defaultdict
import numpy as np
root=Path(__file__).resolve().parent;out=root/'results'
design=json.loads((out/'design.json').read_text())
rows=[json.loads(line) for stage in ('parallel','cost') for line in (out/(stage+'.jsonl')).read_text().splitlines()]
key=lambda r:(r['study'],r['profile'],r['seed'],r['policy'],r['scenario'])
expected={(j['study'],j['profile'],j['seed'],j['policy'],s) for j in design['jobs'] for s in j['scenarios']}
assert len(rows)==len(expected)==3072
assert {key(r) for r in rows}==expected
for name,digest in design['source_sha256'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest
paired=defaultdict(set)
for r in rows:
    paired[(r['study'],r['profile'],r['seed'])].add(r['arrival_sha256'])
    assert r['violations']==0 and r['accounting_error']<1e-6
    assert r['arrived']==r['boarded']+r['end_backlog']
    assert len(r['grid'])==len(r['queue'])==len(r['service'])==465
    assert all(x>=0 for x in r['queue'])
    assert all(a<=b for a,b in zip(r['service'],r['service'][1:]))
    assert r['service'][-1]==r['boarded']
assert all(len(h)==1 for h in paired.values())
core={key(r):r for r in rows if r['study']=='replication'}
contrasts=list(csv.DictReader((out/'paired_comparisons.csv').open()))
for r in contrasts:
    if r['study']!='replication':continue
    differences=[core['replication','base',s,'cross_stochastic',r['scenario']][r['metric']]-core['replication','base',s,'stochastic_rollout',r['scenario']][r['metric']] for s in range(21000,21128)]
    assert abs(np.mean(differences)-float(r['difference']))<1e-10
checks=dict(status='passed',runs=len(rows),planned_jobs_complete=True,source_hashes_match=True,pairing_hashes_match=True,trajectory_conservation=True,replication_means_independently_recomputed=True,violations=0,audit_boardings=sum(r['audit_boardings'] for r in rows))
(out/'integrity_validation.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks))
