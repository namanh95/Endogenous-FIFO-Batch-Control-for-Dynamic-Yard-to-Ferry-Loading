"""Regenerate numerical summaries and vector figures from archived JSONL results."""
import csv,json,itertools,hashlib
from pathlib import Path
from collections import defaultdict
import numpy as np
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from simulator import Config,restoration_time,sustained_confirmation
from revision_experiment import write_csv

OUT=Path('results'); MAN=Path('../../manuscript'); FIG=MAN/'figures'
def ci(x,alpha=.05,key=''):
    x=np.array(x,dtype=float)
    rng=np.random.default_rng(int(hashlib.sha256(key.encode()).hexdigest()[:12],16))
    means=x[rng.integers(0,len(x),(10000,len(x)))].mean(axis=1)
    lo,hi=np.quantile(means,[alpha/2,1-alpha/2])
    return dict(n=len(x),difference=float(x.mean()),ci_low=float(lo),ci_high=float(hi),sd=float(x.std(ddof=1)))

def forest(path,items,title,xlabel,limits=None):
    w,h=600,100+32*len(items);c=canvas.Canvas(str(path),pagesize=(w,h))
    left,right=170,450; bottom,top=48,h-48
    lo=min(x[2] for x in items);hi=max(x[3] for x in items)
    if limits:lo,hi=limits
    else:
        span=max(hi-lo,1);lo=min(0,lo)-span*.12;hi=max(0,hi)+span*.12
    xx=lambda a:left+(a-lo)/(hi-lo)*(right-left)
    c.setFont('Helvetica-Bold',14);c.drawString(14,h-22,title)
    c.setStrokeColor(HexColor('#a0a0a0'));c.setDash(2,3);c.line(xx(0),bottom,xx(0),top+8);c.setDash()
    for i,(label,mean,a,b) in enumerate(items):
        y=top-32*i;c.setFont('Helvetica',12);c.setFillColor(HexColor('#222222'));c.drawString(14,y-3,label)
        c.setStrokeColor(HexColor('#16607a'));c.setFillColor(HexColor('#16607a'));c.setLineWidth(1.5)
        c.line(xx(a),y,xx(b),y);c.line(xx(a),y-4,xx(a),y+4);c.line(xx(b),y-4,xx(b),y+4);c.circle(xx(mean),y,3,fill=1)
        c.setFont('Helvetica',11);c.setFillColor(HexColor('#222222'));c.drawRightString(w-10,y-3,f'{mean:+.2f} [{a:.2f}, {b:.2f}]')
    c.setLineWidth(.6);c.setStrokeColor(HexColor('#777777'));c.line(left,bottom,right,bottom)
    for x in np.linspace(lo,hi,5):c.setFont('Helvetica',11);c.drawCentredString(xx(x),bottom-13,f'{x:.1f}')
    c.setFont('Helvetica',12);c.drawCentredString((left+right)/2,12,xlabel);c.save()

def lineplot(path,series,title,ylabel):
    w,h=540,265;c=canvas.Canvas(str(path),pagesize=(w,h));left,right,bottom,top=52,520,60,220
    vals=np.array([v for _,_,v in series]);lo=min(0,float(vals.min()));hi=float(vals.max())*1.1
    if hi<=lo:hi=lo+1
    xx=lambda x:left+x/464*(right-left);yy=lambda y:bottom+(y-lo)/(hi-lo)*(top-bottom)
    c.setFont('Helvetica-Bold',12);c.drawString(12,244,title);c.setFont('Helvetica',9);c.drawString(12,229,ylabel)
    for y in np.linspace(lo,hi,5):
        c.setStrokeColor(HexColor('#dddddd'));c.line(left,yy(y),right,yy(y));c.setFillColor(HexColor('#222222'));c.drawRightString(left-7,yy(y)-3,f'{y:.1f}')
    for x in (0,120,200,320,464):c.drawCentredString(xx(x),bottom-14,str(x))
    for i,(label,grid,v) in enumerate(series):
        color=('#16607a','#ba4a24','#777777')[i%3];c.setStrokeColor(HexColor(color));c.setLineWidth(1.6)
        p=c.beginPath();p.moveTo(xx(grid[0]),yy(v[0]))
        for x,y in zip(grid[1:],v[1:]):p.lineTo(xx(x),yy(y))
        c.drawPath(p);c.setFillColor(HexColor(color));c.drawString(65+i*210,12,label)
    c.setFillColor(HexColor('#222222'));c.drawCentredString(285,28,'Time (minutes)');c.save()

def main():
    rows=[]
    for stage in ('parallel','cost'):
        rows.extend(json.loads(x) for x in (OUT/f'{stage}.jsonl').read_text().splitlines())
    assert len(rows)==3072 and len({(r['study'],r['profile'],r['policy'],r['seed'],r['scenario']) for r in rows})==3072
    write_csv(OUT/'runs.csv',({k:v for k,v in r.items() if not isinstance(v,(list,dict))} for r in rows))
    groups=defaultdict(list)
    for r in rows:groups[(r['study'],r['profile'],r['scenario'],r['policy'])].append(r)
    comps=[]
    metrics=('boarded','weighted_residence','objective','positive_service_lag_area','restricted_confirmation_minutes')
    for study in ('replication','sensitivity'):
        profiles=['base'] if study=='replication' else ['forecast_low','forecast_high','mixed_discharge','handling_heterogeneity']
        for profile,scenario in itertools.product(profiles,('nominal','cancelled','lane_closure','slow_handling')):
            a={r['seed']:r for r in groups[(study,profile,scenario,'cross_stochastic')]};b={r['seed']:r for r in groups[(study,profile,scenario,'stochastic_rollout')]}
            for metric in metrics:
                if metric not in next(iter(a.values())):continue
                d=[a[k][metric]-b[k][metric] for k in sorted(a)]
                assert all(a[k]['arrival_sha256']==b[k]['arrival_sha256'] for k in a)
                row=dict(study=study,profile=profile,scenario=scenario,metric=metric,**ci(d,key=f'{study}{profile}{scenario}{metric}'))
                if study=='replication' and metric=='boarded':
                    adj=ci(d,.0125,key=f'{study}{profile}{scenario}{metric}');row.update(family_ci_low=adj['ci_low'],family_ci_high=adj['ci_high'])
                comps.append(row)
    write_csv(OUT/'paired_comparisons.csv',comps)
    fac=[];ints=[]
    for scenario in ('nominal','slow_handling'):
        hd={}
        for term,fore,cont in itertools.product((0,1),(0,1),('myopic','fixed2')):
            a={r['seed']:r for r in groups[('factorial','base',scenario,f'h1_t{term}_f{fore}_{cont}')]};b={r['seed']:r for r in groups[('factorial','base',scenario,f'h0_t{term}_f{fore}_{cont}')]}
            d=np.array([a[k]['boarded']-b[k]['boarded'] for k in sorted(a)])
            hd[(term,fore,cont)]=d
            fac.append(dict(scenario=scenario,terminal=term,forecast=fore,continuation=cont,**ci(d,key=f'fac{scenario}{term}{fore}{cont}')))
        for label,d in [('horizon_mean',np.mean(list(hd.values()),axis=0)),('horizon_x_terminal',np.mean([hd[1,f,c]-hd[0,f,c] for f,c in itertools.product((0,1),('myopic','fixed2'))],axis=0)),('horizon_x_forecast',np.mean([hd[t,1,c]-hd[t,0,c] for t,c in itertools.product((0,1),('myopic','fixed2'))],axis=0)),('horizon_x_continuation_fixed2_minus_myopic',np.mean([hd[t,f,'fixed2']-hd[t,f,'myopic'] for t,f in itertools.product((0,1),(0,1))],axis=0))]:
            ints.append(dict(scenario=scenario,effect=label,**ci(d,key=scenario+label)))
    write_csv(OUT/'factorial_horizon.csv',fac);write_csv(OUT/'factorial_interactions.csv',ints)
    rec=[];rawrec=[];cfg=Config()
    for scenario in ('cancelled','lane_closure','slow_handling'):
        start=restoration_time(scenario,cfg);follow=cfg.horizon-start
        for kind,thresholds in [('absolute',(5,10,20)),('relative',(0,2,5))]:
            for th,hold in itertools.product(thresholds,(5,10,20)):
                bypol={}
                for pol in ('stochastic_rollout','cross_stochastic'):
                    nominal={r['seed']:r for r in groups[('replication','base','nominal',pol)]}
                    vals={};confirmed=0
                    for r in groups[('replication','base',scenario,pol)]:
                        values=np.array(r['queue'])
                        if kind=='relative':values=values-np.array(nominal[r['seed']]['queue'])
                        t=sustained_confirmation(r['grid'],values,start,th,hold)
                        vals[r['seed']]=follow if t is None else t;confirmed+=t is not None
                        rawrec.append(dict(scenario=scenario,kind=kind,threshold=th,hold=hold,policy=pol,seed=r['seed'],confirmed=t is not None,confirmation=t,restricted=vals[r['seed']],followup=follow))
                    bypol[pol]=vals
                    rec.append(dict(scenario=scenario,kind=kind,threshold=th,hold=hold,policy=pol,n=len(vals),confirmed=confirmed,censored=len(vals)-confirmed,restricted_mean=np.mean(list(vals.values())),followup=follow))
                d=[bypol['cross_stochastic'][k]-bypol['stochastic_rollout'][k] for k in sorted(bypol['cross_stochastic'])]
                rec.append(dict(scenario=scenario,kind=kind,threshold=th,hold=hold,policy='paired_difference',**ci(d,key=f'rec{scenario}{kind}{th}{hold}'),followup=follow))
    write_csv(OUT/'recovery_sensitivity.csv',rec);write_csv(OUT/'recovery_observations.csv',rawrec)
    cost=[]
    for (study,profile,scenario,policy),g in groups.items():
        if study!='cost':continue
        row=dict(scenario=scenario,policy=policy,n=len(g))
        for field in ('boarded','weighted_residence','objective','latency_mean_ms','latency_p99_ms','latency_max_ms'):
            row[field]=float(np.mean([r[field] for r in g]))
        row['worst_decision_ms']=max(r['latency_max_ms'] for r in g);cost.append(row)
    write_csv(OUT/'quality_cost.csv',cost)
    costpairs=[]
    for scenario in ('nominal','slow_handling'):
        for a_name,b_name in [('cross_b5_s1','local_b5_s3'),('cross_b5_s3','local_b5_s3'),('cross_b2_s1','local_b2_s1')]:
            aa={r['seed']:r for r in groups[('cost','base',scenario,a_name)]};bb={r['seed']:r for r in groups[('cost','base',scenario,b_name)]}
            for metric in ('boarded','weighted_residence','latency_mean_ms'):
                costpairs.append(dict(scenario=scenario,policy=a_name,reference=b_name,metric=metric,**ci([aa[k][metric]-bb[k][metric] for k in sorted(aa)],key=f'cost{scenario}{a_name}{b_name}{metric}')))
    write_csv(OUT/'quality_cost_pairs.csv',costpairs)
    verification=dict(runs=len(rows),audit_boardings=sum(r['audit_boardings'] for r in rows),violations=sum(r['violations'] for r in rows),max_accounting_error=max(r['accounting_error'] for r in rows),counts={s:sum(r['study']==s for r in rows) for s in ('replication','factorial','sensitivity','cost')})
    (OUT/'verification.json').write_text(json.dumps(verification,indent=2))
    FIG.mkdir(exist_ok=True)
    names={'nominal':'Nominal','cancelled':'Cancellation','lane_closure':'Lane closure','slow_handling':'Handling slowdown'}
    rr=[r for r in comps if r['study']=='replication' and r['metric']=='boarded']
    forest(FIG/'replication_effects.pdf',[(names[r['scenario']],r['difference'],r['family_ci_low'],r['family_ci_high']) for r in rr],'Independent replication: 128 paired seeds','Completed vehicles: cross-departure minus within-window')
    old=list(csv.DictReader(Path('../focused_study/focused_results/comparisons.csv').open()))
    old=[r for r in old if r['profile']=='core' and r['policy']=='cross_stochastic' and r['reference']=='stochastic_rollout' and r['metric']=='boarded']
    forest(FIG/'paired_effects.pdf',[(names[r['scenario']],float(r['difference']),float(r['ci_low']),float(r['ci_high'])) for r in old],'Original exploratory study: eight paired seeds','Completed vehicles: cross-departure minus within-window')
    f=[r for r in fac if r['scenario']=='slow_handling']
    forest(FIG/'factorial_effects.pdf',[(f"T{r['terminal']} F{r['forecast']} {r['continuation']}",r['difference'],r['ci_low'],r['ci_high']) for r in f],'Slowdown: horizon effect by controller components','Completed vehicles: extended minus local horizon')
    traj=[]
    for scenario in ('cancelled','lane_closure','slow_handling'):
        series=[]
        for pol in ('stochastic_rollout','cross_stochastic'):
            g=groups[('replication','base',scenario,pol)];vals=np.mean([r['queue'] for r in g],axis=0)
            series.append(('Within-window' if pol=='stochastic_rollout' else 'Cross-departure',g[0]['grid'],vals))
            for t,v in zip(g[0]['grid'],vals):traj.append(dict(scenario=scenario,policy=pol,time=t,mean_queue=v))
        lineplot(FIG/f'recovery_{scenario}.pdf',series,names[scenario]+': mean queue trajectories','Unboarded vehicles (128 seeds)')
    write_csv(OUT/'mean_trajectories.csv',traj)
    print(json.dumps(verification));print('PRIMARY',next(r for r in rr if r['scenario']=='slow_handling'))
    print('INTERACTIONS',json.dumps(ints));print('COST',json.dumps(cost))

if __name__=='__main__':main()

