"""Prospectively fixed resubmission experiments; run from this directory.
No original performance code is changed. Timing study runs sequentially.
"""
import argparse, csv, hashlib, itertools, json, platform, time
from pathlib import Path
from dataclasses import asdict, replace
from concurrent.futures import ProcessPoolExecutor
import numpy as np
import simulator as sim

ORIGINAL_CHOOSE = sim.choose
SCENARIOS = ('nominal','cancelled','lane_closure','slow_handling')

def evaluate(state, first, forecast, end, terminal=True, continuation='myopic'):
    s=state.clone(); idx=0
    idx=sim.idle(s,forecast,idx,min(s.cutoff,end)) if first is None else sim.execute(s,first,forecast,idx)
    while True:
        stop=min(end,s.cutoff)
        while s.t<stop-sim.EPS:
            acts=sim.feasible(s,stop)
            a=sim.myopic(s,acts) if continuation=='myopic' else sim.fixed2(s,acts)
            idx=sim.idle(s,forecast,idx,stop) if a is None else sim.execute(s,a,forecast,idx)
        if abs(s.t-s.cutoff)<sim.EPS: sim.close_cost(s)
        if s.t>=end-sim.EPS: break
        opening=(s.k+1)*s.cfg.cycle
        if opening>=end-sim.EPS:
            sim.advance(s,end,forecast,idx); break
        idx=sim.advance(s,opening,forecast,idx)
        s.open_window(s.k+1,s.mode)
    return sim.objective(s,terminal)

def variant_values(s,acts,rate,seed,spec):
    end=min(s.cutoff,s.t+s.cfg.lookahead)
    if spec['extended'] and s.cutoff-s.t<=s.cfg.lookahead+sim.EPS and s.k+1<s.cfg.sailings:
        end=(s.k+1)*s.cfg.cycle+s.cfg.window
    eligible=[a for a in acts if s.t+a.duration<=min(end,s.cutoff)+sim.EPS]
    if not eligible: return [],[]
    cand=sorted(eligible,key=lambda a:sim.myopic_key(s,a),reverse=True)[:s.cfg.beam]+[None]
    forecasts=[[]] if not spec['forecast'] else [sim.arrivals(2000000000+seed+7919*j,rate*s.cfg.forecast_ratio,s.cfg,start=s.t,end=end,initial=False,id_offset=1000000+j*10000) for j in range(s.cfg.scenarios)]
    vals=[sum(evaluate(s,a,f,end,spec['terminal'],spec['continuation']) for f in forecasts)/len(forecasts) for a in cand]
    return cand,vals

def write_csv(path, rows):
    rows=list(rows)
    keys=list(dict.fromkeys(k for r in rows for k in r))
    with Path(path).open('w',newline='') as f:
        w=csv.DictWriter(f,keys); w.writeheader(); w.writerows(rows)

def jobs():
    out=[]
    for seed in range(21000,21128):
        for p in ('stochastic_rollout','cross_stochastic'):
            out.append(dict(study='replication',seed=seed,policy=p,profile='base',scenarios=SCENARIOS))
    for seed in range(31000,31024):
        for ext,term,fore,cont in itertools.product((False,True),(False,True),(False,True),('myopic','fixed2')):
            spec=dict(extended=ext,terminal=term,forecast=fore,continuation=cont)
            name=f"h{int(ext)}_t{int(term)}_f{int(fore)}_{cont}"
            out.append(dict(study='factorial',seed=seed,policy=name,profile='base',spec=spec,scenarios=('nominal','slow_handling')))
    for profile in ('forecast_low','forecast_high','mixed_discharge','handling_heterogeneity'):
        for seed in range(41000,41032):
            for p in ('stochastic_rollout','cross_stochastic'):
                out.append(dict(study='sensitivity',seed=seed,policy=p,profile=profile,scenarios=SCENARIOS))
    # Timing seeds are separate; sequential execution avoids inter-worker contention.
    for seed in range(51000,51016):
        for beam,n,ext in itertools.product((2,5),(1,3),(False,True)):
            out.append(dict(study='cost',seed=seed,policy=f"{'cross' if ext else 'local'}_b{beam}_s{n}",profile='base',beam=beam,samples=n,spec=dict(extended=ext,terminal=True,forecast=True,continuation='myopic'),scenarios=('nominal','slow_handling')))
    return out

def run_job(job):
    cfg=sim.Config(); profile=job['profile']; seed=job['seed']
    if profile=='forecast_low': cfg=replace(cfg,forecast_ratio=.7)
    if profile=='forecast_high': cfg=replace(cfg,forecast_ratio=1.3)
    if profile=='mixed_discharge': cfg=replace(cfg,mixed_discharge=True)
    if 'beam' in job: cfg=replace(cfg,beam=job['beam'],scenarios=job['samples'])
    stream=sim.arrivals(seed,.48,cfg)
    if profile=='handling_heterogeneity':
        rng=np.random.default_rng(seed+8000000)
        stream=[replace(v,handling=v.handling*float(rng.lognormal(-.3**2/2,.3))) for v in stream]
    digest=hashlib.sha256(json.dumps([asdict(v) for v in stream],sort_keys=True).encode()).hexdigest()
    if 'spec' in job:
        def chooser(s,policy,acts,rate,seed):
            if not acts:return None
            cand,vals=variant_values(s,acts,rate,seed,job['spec'])
            return cand[min(range(len(cand)),key=lambda j:vals[j])] if cand else sim.myopic(s,acts)
        sim.choose=chooser
    else: sim.choose=ORIGINAL_CHOOSE
    results=[]
    for scenario in job['scenarios']:
        r=sim.simulate(cfg,stream,.48,job['policy'],scenario,seed)
        if scenario=='nominal': nominal=r
        else:r.update(sim.paired_disruption_metrics(r,nominal,cfg))
        r.update(study=job['study'],profile=profile,arrival_sha256=digest,beam=cfg.beam,samples=cfg.scenarios)
        if 'spec' in job:r.update(job['spec'])
        results.append(r)
    sim.choose=ORIGINAL_CHOOSE
    return results

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--workers',type=int,default=4); ap.add_argument('--stage',choices=('parallel','cost'),default='parallel'); ap.add_argument('--freeze',action='store_true'); args=ap.parse_args()
    out=Path('results');out.mkdir(exist_ok=True)
    plan=jobs()
    if args.freeze:
        manifest=dict(design='Fixed before new outcome inspection',primary='Cross minus within-window stochastic completed vehicles under handling slowdown, 128 fresh paired seeds; other contrasts secondary.',precision='Fixed sample size 128 (16 times prior eight-seed core); no optional stopping or result-dependent extension. Intended to reduce Monte Carlo standard error by about four under comparable variance, not a guaranteed CI width.',factorial='2x2x2x2: horizon, terminal quadratic cost on/off, forecast on/off, myopic/fixed2 continuation; 24 paired seeds per cell; nominal and slowdown.',cost='Two beams x two sample counts x two horizons, 16 fresh paired seeds, nominal and slowdown; sequential timing; quality versus cost, not equal-runtime superiority.',recovery='Absolute thresholds 5,10,20 and relative excess thresholds 0,2,5 crossed with holds 5,10,20 min; one-minute grid; all 128 replication seeds.',inference='10000 paired bootstrap resamples; core four throughput contrasts also receive Bonferroni 98.75% intervals. Secondary analyses exploratory.',planned_runs=sum(len(j['scenarios']) for j in plan),jobs=plan,python=platform.python_version(),numpy=np.__version__,platform=platform.platform(),source_sha256={n:hashlib.sha256(Path(n).read_bytes()).hexdigest() for n in ('simulator.py','revision_experiment.py')})
        (out/'design.json').write_text(json.dumps(manifest,indent=2));print('Frozen',manifest['planned_runs'],'runs');return
    frozen=json.loads((out/'design.json').read_text())
    assert frozen['jobs']==json.loads(json.dumps(plan)), 'Plan differs from frozen design'
    for name,digest in frozen['source_sha256'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest
    selected=[j for j in plan if (j['study']=='cost')==(args.stage=='cost')]
    path=out/f'{args.stage}.jsonl'; done=set()
    if path.exists():
        for line in path.open():
            r=json.loads(line);done.add((r['study'],r['profile'],r['seed'],r['policy'],r['scenario']))
    selected=[j for j in selected if not all((j['study'],j['profile'],j['seed'],j['policy'],s) in done for s in j['scenarios'])]
    started=time.perf_counter();count=0
    with path.open('a') as f:
        if args.stage=='cost': iterator=map(run_job,selected); pool=None
        else:pool=ProcessPoolExecutor(max_workers=args.workers);iterator=pool.map(run_job,selected)
        for results in iterator:
            for r in results:
                key=(r['study'],r['profile'],r['seed'],r['policy'],r['scenario'])
                if key not in done:f.write(json.dumps(r)+'\n');done.add(key)
            f.flush();count+=len(results)
            if count%32==0:print(args.stage,count,'runs',round(time.perf_counter()-started,1),'seconds',flush=True)
        if pool:pool.shutdown()
    print('COMPLETE',args.stage,count,flush=True)

if __name__=='__main__':main()
