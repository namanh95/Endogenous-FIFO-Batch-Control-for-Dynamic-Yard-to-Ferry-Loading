import unittest
from dataclasses import replace
from unittest.mock import patch
import simulator as s
from revision_experiment import evaluate,variant_values,run_job
from test_simulator import state_with,v

class RevisionTests(unittest.TestCase):
    def test_original_scores_reproduced(self):
        cfg=replace(s.Config(),initial=0,sailings=2)
        for t in (0,13):
            st=state_with(cfg,[v(),v(1,y=1)]);st.t=t
            acts=s.feasible(st)
            for ext in (False,True):
                for forecast in (False,True):
                    spec=dict(extended=ext,terminal=True,forecast=forecast,continuation='myopic')
                    c,x=variant_values(st,acts,.48,73,spec)
                    d,y=s.cross_values(st,acts,.48,73,forecast) if ext else s.rollout_values(st,acts,'stochastic_rollout' if forecast else 'deterministic_rollout',.48,73)
                    self.assertEqual(c,d)
                    for a,b in zip(x,y):self.assertAlmostEqual(a,b)

    def test_terminal_toggle_only_removes_backlog(self):
        cfg=replace(s.Config(),initial=0,sailings=2,window=1,cycle=3)
        st=state_with(cfg,[v(0,width=8)])
        for cont in ('myopic','fixed2'):
            self.assertAlmostEqual(evaluate(st,None,[],4,True,cont)-evaluate(st,None,[],4,False,cont),2)
            self.assertAlmostEqual(evaluate(st,None,[],4,False,cont),44)

    def test_both_sides_of_balance_and_reference_mass(self):
        for coord in (-3,3):
            cfg=replace(s.Config(),initial=0,lanes=(s.Lane(transverse=coord),))
            st=state_with(cfg,[v(0,mass=20)])
            self.assertEqual(s.feasible(st),[])
            st=state_with(cfg,[v(0,mass=10)])
            self.assertTrue(s.feasible(st))

    def test_no_future_mode_lookup_and_state_isolation(self):
        st=state_with(replace(s.Config(),initial=0),[v()]);st.t=13
        import copy; before=copy.deepcopy(st)
        with patch('simulator.mode_for',side_effect=AssertionError('future lookup')):
            for c in ('myopic','fixed2'):
                variant_values(st,s.feasible(st),.48,73,dict(extended=True,terminal=False,forecast=True,continuation=c))
        self.assertEqual(st,before)

    def test_forecast_prefix_shared_across_horizons(self):
        cfg=s.Config()
        short=s.arrivals(98765,.48,cfg,start=13,end=24,initial=False)
        long=s.arrivals(98765,.48,cfg,start=13,end=64,initial=False)
        self.assertEqual(short,[v for v in long if v.arrival<24-s.EPS])

if __name__=='__main__':unittest.main(verbosity=2)

