import unittest,json
from dataclasses import replace
from unittest.mock import patch
from pathlib import Path
from simulator import *
from test_simulator import v,state_with

class ExtensionTests(unittest.TestCase):
    def test_published_single_action_arithmetic(self):
        cfg=replace(Config(),lanes=(Lane(transverse=0),),initial=0)
        s=state_with(cfg,[v()]); a=feasible(s)[0]
        # First batch: no yard switch, no moment; exact Eq16 adaptation.
        self.assertAlmostEqual(published_cost(s,a,{0:1}),5-12-1+.8*(28-4.45)/28)
        c,vals=two_batch_values(s,[a]); self.assertEqual(c,[a])
        self.assertAlmostEqual(vals[0],published_cost(s,a,{0:1}))

    def test_all_first_actions_against_direct_enumeration(self):
        cfg=replace(Config(),initial=0,window=4)
        s=state_with(cfg,[v(0),v(1),v(2,y=1)])
        for matched in (True,False):
            acts=feasible(s); cand,values=two_batch_values(s,acts,matched,beam=0)
            ages={i:1 for i in range(3)}; direct=[]
            for a in acts:
                nxt=s.clone(); execute(nxt,a,[],0)
                if matched and abs(nxt.t-nxt.cutoff)<EPS: close_cost(nxt)
                c1=objective(nxt,False)-objective(s,False) if matched else published_cost(s,a,ages)
                second=feasible(nxt); costs=[]
                for b in second or [None]:
                    leaf=nxt.clone()
                    if b: execute(leaf,b,[],0)
                    if b and matched and abs(leaf.t-leaf.cutoff)<EPS: close_cost(leaf)
                    c2=(objective(leaf,False)-objective(nxt,False) if matched else published_cost(nxt,b,ages)) if b else 0
                    term=cfg.gamma*sum(x*x for x in leaf.counts()) if matched else 1.5*sum(ages[x.id]**2*x.weight for q in leaf.q for x in q)
                    costs.append(c1+c2+term)
                direct.append(min(costs))
            self.assertAlmostEqual(min(values),min(direct))

    def test_cross_cutoffs_charge_once_and_preserve_queue(self):
        cfg=replace(Config(),initial=0,sailings=2,window=1,cycle=3)
        s=state_with(cfg,[v(0,width=8)])
        leaf=cross_continuation(s,None,[],4,True)
        self.assertEqual(leaf.k,1); self.assertEqual(leaf.missed,2)
        self.assertEqual(leaf.area,4); self.assertEqual(leaf.counts(),[1,0,0])

    def test_reset_allows_carryover_service(self):
        cfg=replace(Config(),initial=0,sailings=2,window=1,cycle=3)
        s=state_with(cfg,[v(0),v(1)])
        leaf=cross_continuation(s,feasible(s)[0],[],4,True)
        self.assertEqual(sum(leaf.counts()),0); self.assertEqual(leaf.missed,1)
        self.assertAlmostEqual(leaf.area,5); self.assertAlmostEqual(leaf.setup_minutes,1)

    def test_modes_are_not_read_from_future(self):
        cfg=replace(Config(),initial=0,sailings=2)
        s=state_with(cfg,[v()]); s.t=13
        with patch('simulator.mode_for',side_effect=AssertionError('future mode leak')):
            cross_values(s,feasible(s),.48,73)
        self.assertEqual(s.t,13); self.assertEqual(len(s.q[0]),1)

    def test_cross_equals_local_before_activation_and_last_sailing(self):
        cfg=replace(Config(),initial=0,sailings=2)
        s=state_with(cfg,[v(),v(1,y=1)])
        for k,t in [(0,0),(1,53)]:
            s.open_window(k,Mode()); s.t=t
            self.assertEqual(cross_values(s,feasible(s),.48,91),rollout_values(s,feasible(s),'stochastic_rollout',.48,91))

    def test_new_policies_full_engine_audit(self):
        cfg=replace(Config(),sailings=2,initial=4,shock_sailing=0)
        stream=arrivals(90000,.15,cfg)
        for p in ('adapted_btr','matched_btr','cross_deterministic','cross_stochastic'):
            r=simulate(cfg,stream,.15,p,'lane_closure',90000)
            self.assertEqual(r['violations'],0)
            self.assertEqual(r['arrived'],r['boarded']+r['end_backlog'])

if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(ExtensionTests))
    Path('extension_test_results.json').write_text(json.dumps({'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'successful':result.wasSuccessful()},indent=2))
    raise SystemExit(0 if result.wasSuccessful() else 1)
