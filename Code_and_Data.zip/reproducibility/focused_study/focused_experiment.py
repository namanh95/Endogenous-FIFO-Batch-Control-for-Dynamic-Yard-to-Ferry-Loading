"""Fixed modest budget: 224 core + 192 sensitivity = 416 synthetic runs."""
import csv,json,hashlib,time
from pathlib import Path
from dataclasses import asdict,replace
import numpy as np
from simulator import *
from experiments import write_csv

CORE=('myopic','adapted_btr','matched_btr','deterministic_rollout','stochastic_rollout','cross_deterministic','cross_stochastic')
SCENARIOS=('nominal','cancelled','lane_closure','slow_handling')
METRICS=('boarded','weighted_residence','objective','positive_service_lag_area','restricted_confirmation_minutes')

def main():
    out=Path('focused_results'); out.mkdir(exist_ok=True)
    profiles=[('core',Config(),range(12000,12008),CORE),
      ('forecast_low',replace(Config(),forecast_ratio=.7),range(13000,13004),('adapted_btr','stochastic_rollout','cross_stochastic')),
      ('forecast_high',replace(Config(),forecast_ratio=1.3),range(13000,13004),('adapted_btr','stochastic_rollout','cross_stochastic')),
      ('mixed_discharge',replace(Config(),mixed_discharge=True),range(13000,13004),('adapted_btr','stochastic_rollout','cross_stochastic')),
      ('handling_heterogeneity',Config(),range(13000,13004),('adapted_btr','stochastic_rollout','cross_stochastic'))]
    manifest={'rate':.48,'profiles':[{ 'name':n,'config':asdict(c),'seeds':list(seeds),'policies':ps} for n,c,seeds,ps in profiles],
      'scenarios':SCENARIOS,'planned_runs':416,'development_note':'Fixed design before results; fresh seeds; small exploratory study, no tuning on evaluation outcomes.',
      'handling_profile':'Multiply actual vehicle handling by independent mean-one lognormal factors sigma=0.3; revealed on arrival, then exact. Forecasts retain base handling times.',
      'future_modes':'Observed mode persists in cross-cutoff forecasts; no true future scenario schedule is exposed.',
      'timing':'CPU measured but consumes zero physical time; horizons do not have equal CPU budgets.',
      'source_sha256':{n:hashlib.sha256(Path(n).read_bytes()).hexdigest() for n in ('simulator.py','focused_experiment.py')}}
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2)); rows=[]; tic=time.perf_counter()
    for profile,cfg,seeds,policies in profiles:
      for seed in seeds:
        stream=arrivals(seed,.48,cfg)
        if profile=='handling_heterogeneity':
          rng=np.random.default_rng(seed+8000000)
          stream=[replace(v,handling=v.handling*float(rng.lognormal(-.3**2/2,.3))) for v in stream]
        digest=hashlib.sha256(json.dumps([asdict(v) for v in stream],sort_keys=True).encode()).hexdigest()
        for policy in policies:
          nominal=None
          for scenario in SCENARIOS:
            r=simulate(cfg,stream,.48,policy,scenario,seed)
            if scenario=='nominal':nominal=r
            else:r.update(paired_disruption_metrics(r,nominal,cfg))
            row={k:v for k,v in r.items() if not isinstance(v,(list,dict))}
            row.update(profile=profile,arrival_sha256=digest);rows.append(row)
        write_csv(out/'runs.csv',rows)
        print(profile,seed,len(rows),'runs',round(time.perf_counter()-tic,1),'s',flush=True)
    groups={}
    for r in rows:groups.setdefault((r['profile'],r['scenario'],r['policy']),[]).append(r)
    summary=[]
    for (profile,scenario,policy),g in groups.items():
      row=dict(profile=profile,scenario=scenario,policy=policy,n=len(g))
      for m in (*METRICS,'latency_mean_ms','latency_max_ms'):
        vals=[r[m] for r in g if r.get(m) is not None]
        if vals:row[m]=float(np.mean(vals))
      if scenario!='nominal':row['nonrecovery_fraction']=1-float(np.mean([r['recovered'] for r in g]))
      summary.append(row)
    write_csv(out/'summary.csv',summary)
    pairs=[('adapted_btr','myopic'),('matched_btr','adapted_btr'),('deterministic_rollout','matched_btr'),
           ('stochastic_rollout','deterministic_rollout'),('cross_deterministic','deterministic_rollout'),
           ('cross_stochastic','stochastic_rollout'),('cross_stochastic','cross_deterministic'),('cross_stochastic','adapted_btr')]
    comparisons=[];rng=np.random.default_rng(20261023)
    for profile,_,seeds,_ in profiles:
      for scenario in SCENARIOS:
        for policy,reference in pairs:
          a=groups.get((profile,scenario,policy));b=groups.get((profile,scenario,reference))
          if not a or not b:continue
          b={r['seed']:r for r in b}
          for m in METRICS:
            d=np.array([r[m]-b[r['seed']][m] for r in a if r.get(m) is not None])
            if not len(d):continue
            boots=d[rng.integers(len(d),size=(2000,len(d)))].mean(axis=1)
            comparisons.append(dict(profile=profile,scenario=scenario,policy=policy,reference=reference,metric=m,n=len(d),
              difference=float(d.mean()),ci_low=float(np.quantile(boots,.025)),ci_high=float(np.quantile(boots,.975))))
    write_csv(out/'comparisons.csv',comparisons)
    (out/'verification.json').write_text(json.dumps(dict(runs=len(rows),audit_boardings=sum(r['audit_boardings'] for r in rows),
      violations=sum(r['violations'] for r in rows),maximum_accounting_error=max(r['accounting_error'] for r in rows),elapsed_seconds=time.perf_counter()-tic),indent=2))
    print('Completed',len(rows),'runs',flush=True)
if __name__=='__main__':main()
